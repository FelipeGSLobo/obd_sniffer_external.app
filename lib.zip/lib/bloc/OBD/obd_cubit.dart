import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:obd_log/data/models/obd_log.dart';
import '../../data/models/obd_device.dart';
import '../../data/repositories/obd_repository.dart';

class ObdCubit extends Cubit<List<ObdLogModel>> {
  final ObdRepository _repository = ObdRepository();
  StreamSubscription? _notifySub;

  ObdCubit() : super([]);

  Future<List<ObdDevice>> scanDevices() async {
    return await _repository.scanDevices();
  }

  Future<void> connectDevice(ObdDevice device) async {
    // Simulação de conexão e log CAN
    // Aqui você substitui pelo código real de BLE/ELM327
    _notifySub?.cancel();

    // Limpa logs
    emit([]);

    // Simula chegada de frames CAN
    _notifySub = Stream.periodic(const Duration(milliseconds: 500), (count) {
      return "7E8 ${count.toRadixString(16).padLeft(2, '0')} AB CD EF";
    }).listen((frame) {
      final current = List.of(state);
      current.add(ObdLogModel(frame: frame, timestamp: DateTime.now()));
      emit(current);
    });
  }

  Future<void> stop() async {
    await _notifySub?.cancel();
  }
}
