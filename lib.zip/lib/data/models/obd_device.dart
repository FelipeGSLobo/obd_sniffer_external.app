import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class ObdDevice {
  final DeviceIdentifier id;
  final String name;

  ObdDevice({required this.id, required this.name});
}
