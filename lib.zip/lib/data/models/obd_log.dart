class ObdLogModel {
  final String frame;
  final DateTime timestamp;

  ObdLogModel(
      {required this.frame, required this.timestamp, required String message});
}
