import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:obd_log/data/models/obd_log.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/obd_device.dart';
import 'dart:async';
import 'dart:convert';

class ObdProvider {
  BluetoothDevice? _device;
  BluetoothCharacteristic? _writeChar;
  BluetoothCharacteristic? _notifyChar;

  Future<List<ObdDevice>> scanDevices() async {
    List<ObdDevice> devices = [];

    await Permission.bluetoothScan.request();
    await Permission.bluetoothConnect.request();
    await Permission.location.request();

    await FlutterBluePlus.startScan(
      timeout: const Duration(seconds: 5),
      androidScanMode: AndroidScanMode.lowLatency,
    );

    final subscription = FlutterBluePlus.scanResults.listen((results) {
      for (var r in results) {
        final id = r.device.remoteId;
        if (!devices.any((d) => d.id == id)) {
          devices.add(ObdDevice(
            name: r.device.advName.isNotEmpty ? r.device.advName : "Unknown",
            id: id,
          ));
        }
      }
    });

    await Future.delayed(const Duration(seconds: 5));
    await FlutterBluePlus.stopScan();
    await subscription.cancel();

    return devices;
  }

  Future<void> connect(ObdDevice device) async {
    _device =
        BluetoothDevice(id: DeviceIdentifier(device.id), name: device.name);
    await _device!.connect();

    List<BluetoothService> services = await _device!.discoverServices();
    for (var s in services) {
      for (var c in s.characteristics) {
        if (c.properties.write) _writeChar = c;
        if (c.properties.notify) _notifyChar = c;
      }
    }

    if (_notifyChar != null) {
      await _notifyChar!.setNotifyValue(true);
    }
  }

  void startListening(Function(ObdLogModel) onData) {
    if (_notifyChar == null) return;
    _notifyChar!.value.listen((data) {
      String hex =
          data.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');
      onData(ObdLogModel(message: hex, timestamp: DateTime.now()));
    });

    // Configura ELM327
    List<String> commands = [
      "AT Z",
      "AT DP",
      "AT SP 6",
      "AT DP",
      "AT H1",
      "AT S0",
      "AT L0",
      "AT E0",
      "AT ST 64",
      "0100",
      "AT MA",
    ];
    for (var cmd in commands) {
      sendCommand(cmd);
    }
  }

  Future<void> sendCommand(String command) async {
    if (_writeChar == null) return;
    await _writeChar!.write(utf8.encode("$command\r"));
  }

  Future<void> disconnect() async {
    await _device?.disconnect();
  }
}
