import 'package:obd_log/data/models/obd_log.dart';
import '../models/obd_device.dart';
import '../providers/obd_provider.dart';

class ObdRepository {
  final ObdProvider _provider = ObdProvider();

  Future<List<ObdDevice>> scanDevices() async {
    return await _provider.scanDevices();
  }

  Future<void> connect(ObdDevice device) async =>
      await _provider.connect(device);

  void startListening(Function(ObdLogModel) onData) {
    _provider.startListening(onData);
  }

  void disconnect() => _provider.disconnect();
}
