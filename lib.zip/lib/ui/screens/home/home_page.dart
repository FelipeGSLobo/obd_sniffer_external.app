import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:obd_log/bloc/OBD/obd_cubit.dart';
import 'package:obd_log/data/models/obd_log.dart';
import 'package:obd_log/ui/components/log_container.dart';
import 'package:printing/printing.dart';
import 'package:pdf/widgets.dart' as pw;

import 'widget/connect_button.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ScrollController _scrollController = ScrollController();

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _exportPdf(List<ObdLogModel> logs) async {
    if (logs.isEmpty) return;

    final pdf = pw.Document();
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Text("OBD Log", style: pw.TextStyle(fontSize: 24)),
          pw.SizedBox(height: 16),
          pw.ListView.builder(
            itemCount: logs.length,
            itemBuilder: (context, index) {
              final log = logs[index];
              return pw.Text(
                "${log.timestamp.toIso8601String()} - ${log.message}",
                style: const pw.TextStyle(fontSize: 12),
              );
            },
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("OBD Logger"),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            tooltip: "Exportar log em PDF",
            onPressed: () async {
              final logs = context.read<ObdCubit>().state;
              if (logs.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Nenhum log disponível")),
                );
                return;
              }
              await _exportPdf(logs);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const ConnectButton(),
          Expanded(
            child: BlocConsumer<ObdCubit, List<ObdLogModel>>(
              listener: (_, logs) => _scrollToBottom(),
              builder: (context, logs) {
                return ObdLogContainer(
                  logs: logs,
                  controller: _scrollController,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
